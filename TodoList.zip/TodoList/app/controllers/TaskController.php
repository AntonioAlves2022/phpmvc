<?php

namespace App\Controllers;

use App\Models\Task;

class TaskController {
    public function index(){
        // exibir pagina inicial
    }
    public function create(){
        // exibir o form de cadastro
    }
    public function store(){
        // lógica de cadastro
    }
    public function show($id){
        // exibir dados de um usuario
    }
    public function edit($id){
        // exibe a tela de edição
    }
    public function update($id){
        // logica de edição
    }
    public function delete($id){
        // logica de exclusão
    }




}