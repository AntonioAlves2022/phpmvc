<?php
    namespace App\Models;
    use PDO;

    class Task {
        private $db;
        public function __construct(){

        }

        public function getAll(){

        }

        public function getById(){

        }

        public function create($titulo, $descricao){
        
        }

        public function update($id, $titulo, $descricao){

        }
    }