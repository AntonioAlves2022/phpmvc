<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>To Do List PHP</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <h1>Gerenciador de tarefas PHP</h1>
    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Titulo</th>
                <th>Descricao</th>
                <th>Criada em:</th>
                <th>status</th>
                <th colspan="2">Ações</th>
            </tr>
        </thead>
    </table>
</body>
</html>
